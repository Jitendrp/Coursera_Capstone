import { Course } from './course';

export const COURSES: Course[] = [
  {
    id: 1,
    name: 'c++',
  },
  {
    id: 2,
    name: 'java',
  },
  {
    id: 3,
    name: 'Devops',
  },
  {
    id: 4,
    name: 'Docker',
  },
];
