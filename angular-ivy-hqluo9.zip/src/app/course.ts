export class Course {
  id: number;
  name: string;
}
